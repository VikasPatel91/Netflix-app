import model from "../Models/userModel.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { StatusCodes } from "http-status-codes";
export async function Insert(req, res) {
  try {
    const user = await model({
      email: req.body.email,
      password: await bcrypt.hash(req.body.password, 12),
    });
    const saved = await user.save();
    res.json(saved).status(201);
  } catch (error) {
    res.json(error).status(400);
  }
}

export async function userData(req, res) {
  const user = await model.find();
  res.json(user).status(200);
}

export async function login(req, res) {
  const userEmail = await model.findOne({
    email: req.body.email,
  });
  if (userEmail) {
    if (bcrypt.compareSync(req.body.password, userEmail.password)) {
      const token = jwt.sign({ loginUserId: userEmail._id }, "24680");
      res.status(200).json(`login success, token :${token}`);
    } else {
      res.status(StatusCodes.NOT_ACCEPTABLE);
      res.json("Password is incorrect");
    }
  } else {
    res.status(StatusCodes.NOT_FOUND);
    res.json("invalid email id");
  }
}

export async function userById(req, res) {
  const id = req.params.id;
  const user = await model.findById({ _id: id });
  res.json(user).status(200);
}

export async function userByEmail(req, res) {
  const email = req.params.email;
  const user = await model.findOne({ email:email });
  console.log(user)
  res.json(user).status(200);
}

