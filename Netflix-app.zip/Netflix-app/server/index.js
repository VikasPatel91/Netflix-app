import express from 'express'
import router from './Routers/userRouter.js';
import cors from 'cors'
import './db.js'
const app = express();

app.use(express.json())
app.use(cors())
app.use(router)

app.listen(5000, () => {
  console.log("Server is Running at 5000");
});
